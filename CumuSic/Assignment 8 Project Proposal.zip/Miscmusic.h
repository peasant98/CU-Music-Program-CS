//Matthew Strong
// Recitation 201: Arcadia Zhang
// CSCI 1300 Assignment 8
// Miscmusic.h file

#ifndef MISCMUSIC_H




#define MISCMUSIC_H
//defining this new class, as this is required as part of the C++ syntax needed to declare a class.

#include <iostream>
#include <fstream>
#include <windows.h>
using namespace std;
//this class should not be too hard compared to Happymusic and Sadmusic.
class Miscmusic
{

    public:
        Miscmusic();
        ~Miscmusic();
        //default constructor and destructor
        int playFundamentals(string);
        // plays a simple note exercise based on the desired note for the user.
        string playmajorscale(string);
        // plays a major scale based on the desired starting note.
        string playarpeggio(string);
        // plays an arpeggio based on the desired starting note.
        string playminorscale(string);
        // plays a minor scale based on the desired starting note.
        void playeighthnote(string);
        // plays one eighth note
        void playquarternote(string);
        // plays one quarter note
        void playhalfnote(string);
        // plays one half note
        void playwholenote(string);
        // plays one whole note
        void playRemington(string);

        // plays Remington exercise with a user inputted starting note.
        void playsixthteenthnote(string);
        // plays one sixteenth note
        void setTempo(int);
        // sets the tempo
        int getTempo();
        // gets the current tempo

        int tempo;
        // data member for the tempo
        string startingNote;
        // will be the starting note
        string notes[200];
        // array for every note I will need
        float notefreq[200];
        // array for all of the note frequencies I will need.

};

#endif // MISCMUSIC_H
