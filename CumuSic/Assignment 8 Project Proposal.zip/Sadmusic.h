//Matthew Strong
// Recitation 201: Arcadia Zhang
// CSCI 1300 Assignment 8
// Sadmusic.h file

#ifndef SADMUSIC_H


#define SADMUSIC_H
//defining this new class, as this is required as part of the C++ syntax needed to declare a class.
#include <iostream>
#include <windows.h>
using namespace std;


// One of the harder classes to create.
class Sadmusic
{
    public:
        Sadmusic();
        ~Sadmusic()
        //default constructor and destructor
        int createMusic(string);
        // will create a random music with the user's desired basis (scale), it will not sound great, but should only
        // produce notes in the scale that is a string.

        int upOctave();
        // plays the music up an octave.
        int fasterSadmusic(int);
        // plays faster sad music or slower with the desired tempo.
        string getNote();
        // Gets a note and displays what note it is (example: A4)
        void setTempo(int);
        // setter for the tempo
        int getTempo();
        // getter for the tempo.
        int tempo;
        // the tempo
        string madenotes[1000];
        // the music produced is stored into two arrays, one with the name of the note, and the other with
        // the frequency of the note.
        float madenotesfreq[1000];
        string minor[8];
        float minorfreq[8];
        // the scales in which everything will be based off of.

        string notes[200];
        float notefreq[200];

        // the library, essentially, where I can get any note along with its frequency.


};



#endif // SADMUSIC_H
