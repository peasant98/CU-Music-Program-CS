//Matthew Strong
// Recitation 201: Arcadia Zhang
// CSCI 1300 Assignment 8
// Sadmusic.h file

#ifndef HAPPYMUSIC_H



#define HAPPYMUSIC_H
//defining this new class, as this is required as part of the C++ syntax needed to declare a class.

#include <iostream>
#include <windows.h>
using namespace std;



// Very similar to Sadmusic, just slightly different musical theory.
class Happymusic
{
    public:
        Happymusic();
        ~Happymusic();
        //default constructor and destructor
        int createMusic(string);
        // creates random music with the user's desired scale.

        int upOctave();
        // plays the music up an octave.
        int fasterHappymusic(int);
        // plays the music faster based on the tempo desired.
        string getNote();
        // gets a note from the array of created music.
        void setTempo(int);
        // setter for the tempo.
        int getTempo();
        // gets the current tempo.
        int tempo;
        // the member, tempo.

        string madenotes[1000];
        float madenotesfreq[1000];

        // two arrays that store information about the randomly created notes.
        string major[8];
        float majorfreq[8];

        // the basis, or the scale in which everything is based on.
        string notes[200];
        float notefreq[200];

        // all the notes I will need.




};


#endif // HAPPYMUSIC_H
